## QLearner Tests

To execute tests, place your QLearner.py in the top-level directory and do:

`python -m unittest discover`